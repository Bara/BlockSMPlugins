/**
 * vim: set ts=4 :
 * =============================================================================
 * SourceMod Sample Extension
 * Copyright (C) 2004-2008 AlliedModders LLC.  All rights reserved.
 * =============================================================================
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, version 3.0, as published by the
 * Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * As a special exception, AlliedModders LLC gives you permission to link the
 * code of this program (as well as its derivative works) to "Half-Life 2," the
 * "Source Engine," the "SourcePawn JIT," and any Game MODs that run on software
 * by the Valve Corporation.  You must obey the GNU General Public License in
 * all respects for all other code used.  Additionally, AlliedModders LLC grants
 * this exception to all derivative works.  AlliedModders LLC defines further
 * exceptions, found in LICENSE.txt (as of this writing, version JULY-31-2007),
 * or <http://www.sourcemod.net/license.php>.
 *
 * Version: $Id$
 */

#include "extension.h"
#include "CDetour/detours.h"
#include <sourcehook.h>
#include <IBinTools.h>
#include <iplayerinfo.h>

/**
 * @file extension.cpp
 * @brief Implement extension code here.
 */

PHooks g_PHooks;		/**< Global singleton for extension's main interface */

SMEXT_LINK(&g_PHooks);

IGameConfig *g_pGameConf = NULL;

#define MAXPLAYERS 65
int g_iInventoryOffset = 0;
int g_iGetItemInLoadout = 0;
ICallWrapper *g_pItemSchema = NULL;
ICallWrapper *g_pGetItemInLoadout = NULL;
ICallWrapper *g_pGetItemDefintionByName = NULL;
ICallWrapper *g_pGetLoadoutSlot = NULL;
IBinTools *g_pBinTools = NULL;
CDetour *g_pCDownloadListGenerator = NULL;

int g_iHookId[5][MAXPLAYERS+1];
IChangeableForward *g_pGiveNamedItem = NULL;
IChangeableForward *g_pGiveNamedItemPre = NULL;
IChangeableForward *g_pWeaponCanUse = NULL;
IChangeableForward *g_pSetModel = NULL;
IChangeableForward *g_pSetModelPre = NULL;
IChangeableForward *g_pClientPrintf = NULL;
IChangeableForward *g_pPrecacheModel = NULL;
IChangeableForward *g_pMapContentList = NULL;


void RemoveHook(int client);
void LevelShutdown();
CEconItemView *GetEconItemView(void *pItemDef, CBaseEntity *pEnt, int iTeam);

CBaseEntity *GiveNamedItem(const char *szItem, int iSubType, CEconItemView *pView, bool removeIfNotCarried);
SH_DECL_MANUALHOOK4(GiveNamedItemHook, 0, 0, 0, CBaseEntity *, const char *, int, CEconItemView *, bool);
CBaseEntity *GiveNamedItemPre(const char *szItem, int iSubType, CEconItemView *pView, bool removeIfNotCarried);
SH_DECL_MANUALHOOK4(GiveNamedItemPreHook, 0, 0, 0, CBaseEntity *, const char *, int, CEconItemView *, bool);
bool WeaponCanUse(CBaseCombatWeapon *pWeapon);
SH_DECL_MANUALHOOK1(WeaponCanUseHook, 0, 0, 0, bool, CBaseCombatWeapon *);
CBaseEntity *SetModel(const char *sModel);
SH_DECL_MANUALHOOK1(SetModelHook, 0, 0, 0, CBaseEntity *, const char *);
CBaseEntity *SetModelPre(const char *sModel);
SH_DECL_MANUALHOOK1(SetModelPreHook, 0, 0, 0, CBaseEntity *, const char *);
void ClientPrint(edict_t *pEdict, const char *szMsg);
SH_DECL_HOOK2_void(IVEngineServer, ClientPrintf, SH_NOATTRIB, 0, edict_t *, const char *);
int PrecacheModel(const char *s, bool preload);
SH_DECL_HOOK2(IVEngineServer, PrecacheModel, SH_NOATTRIB, 0, int, const char *, bool);

SH_DECL_HOOK0_void(IServerGameDLL, LevelShutdown, SH_NOATTRIB, false);

sp_nativeinfo_t g_ExtensionNatives[] =
{
	{ "PHook",		PHook },
	{ "PUnHook",		PUnHook },
	{ "PHook_GetCEconItemView",		PHook_GetCEconItemView },
	{ "CEconItemView.IsCustomItemView",		PHook_IsCustomItemView },
	{ "PHook_GivePlayerItem",		PHook_GivePlayerItem },
	{ NULL,							NULL }
};

DETOUR_DECL_MEMBER1(CDownloadListGenerator, int, char *, file_name)
{
	if(g_pMapContentList->GetFunctionCount() > 0)
	{
		char sFileByf[128];
		strcpy(sFileByf, file_name);
		cell_t res = PLUGIN_CONTINUE;
		g_pMapContentList->PushStringEx(sFileByf, sizeof(sFileByf), SM_PARAM_STRING_COPY, SM_PARAM_COPYBACK);
		g_pMapContentList->Execute(&res);

		switch(res) 
		{
			case Pl_Changed:
			{
				DETOUR_MEMBER_CALL(CDownloadListGenerator)(sFileByf);
			}
			case Pl_Handled:
			case Pl_Stop:
			{
				return 0;
			}
		}
	}
	return DETOUR_MEMBER_CALL(CDownloadListGenerator)(file_name);
}

bool PHooks::SDK_OnLoad(char *error, size_t maxlength, bool late)
{
	char conf_error[255];
	
	if(!gameconfs->LoadGameConfigFile("sdktools.games", &g_pGameConf, conf_error, sizeof(conf_error)))
	{
		snprintf(error, maxlength, "Could not read sdktools.games: %s", conf_error);
		return false;
	}

	int offset = -1;
	void *addr;
	int byteOffset = -1;

	if(!g_pGameConf->GetOffset("GiveNamedItem", &offset))
	{
		snprintf(error, maxlength, "Failed to get GiveNamedItem offset");
		return false;
	}
	SH_MANUALHOOK_RECONFIGURE(GiveNamedItemHook, offset, 0, 0);
	SH_MANUALHOOK_RECONFIGURE(GiveNamedItemPreHook, offset, 0, 0);
	
	if(!g_pGameConf->GetOffset("SetEntityModel", &offset))
	{
		snprintf(error, maxlength, "Failed to get SetEntityModel offset");
		return false;
	}
	
	SH_MANUALHOOK_RECONFIGURE(SetModelHook, offset, 0, 0);
	SH_MANUALHOOK_RECONFIGURE(SetModelPreHook, offset, 0, 0);
	
	if(!gameconfs->LoadGameConfigFile("sdkhooks.games", &g_pGameConf, conf_error, sizeof(conf_error)))
	{
		snprintf(error, maxlength, "Could not read sdkhooks.games: %s", conf_error);
		return false;
	}
	
	if(!g_pGameConf->GetOffset("Weapon_CanUse", &offset))
	{
		snprintf(error, maxlength, "Failed to get Weapon_CanUse offset");
		return false;
	}	
	SH_MANUALHOOK_RECONFIGURE(WeaponCanUseHook, offset, 0, 0);
	
	
	if(!gameconfs->LoadGameConfigFile("phooks.games", &g_pGameConf, conf_error, sizeof(conf_error)))
	{
		snprintf(error, maxlength, "Could not read phooks.games: %s", conf_error);
		return false;
	}
	
	if(!g_pGameConf->GetOffset("InventoryOffset", &byteOffset))
	{
		snprintf(error, maxlength, "Failed to get InventoryOffset offset");
		return false;
	}
	if(!g_pGameConf->GetMemSig("HandleCommand_Buy_Internal", &addr) || !addr)
	{
		snprintf(error, maxlength, "Failed to get HandleCommand_Buy_Internal address");
		return false;
	}

	g_iInventoryOffset = *(int *)((intptr_t)addr + byteOffset);

	if(!g_pGameConf->GetOffset("GetItemInLoadout", &g_iGetItemInLoadout))
	{
		snprintf(error, maxlength, "Failed to get GetItemInLoadout offset");
		return false;
	}
	
	CDetourManager::Init(g_pSM->GetScriptingEngine(), g_pGameConf);
	g_pCDownloadListGenerator = DETOUR_CREATE_MEMBER(CDownloadListGenerator, "CDownloadListGenerator");
	if (!g_pCDownloadListGenerator)
	{
		snprintf(error, maxlength, "Detour failed CDownloadListGenerator");
		return false;
	}
	
	sharesys->AddDependency(myself, "bintools.ext", true, true);
	SH_ADD_HOOK(IServerGameDLL, LevelShutdown, gamedll, SH_STATIC(LevelShutdown), true);
	playerhelpers->AddClientListener(&g_PHooks);
	
	SH_ADD_HOOK(IVEngineServer, ClientPrintf, engine, SH_STATIC(ClientPrint), false);
	SH_ADD_HOOK(IVEngineServer, PrecacheModel, engine, SH_STATIC(PrecacheModel), false);
	
	g_pCDownloadListGenerator->EnableDetour();
	
	g_pGiveNamedItem = forwards->CreateForwardEx(NULL, ET_Ignore, 4, NULL, Param_Cell, Param_String, Param_Cell, Param_Cell);
	g_pGiveNamedItemPre = forwards->CreateForwardEx(NULL, ET_Hook, 3, NULL, Param_Cell, Param_String, Param_CellByRef);
	g_pWeaponCanUse = forwards->CreateForwardEx(NULL, ET_Hook, 3, NULL, Param_Cell, Param_Cell, Param_Cell);
	g_pSetModel = forwards->CreateForwardEx(NULL, ET_Ignore, 2, NULL, Param_Cell, Param_String);
	g_pSetModelPre = forwards->CreateForwardEx(NULL, ET_Hook, 3, NULL, Param_Cell, Param_String, Param_String);
	g_pClientPrintf = forwards->CreateForwardEx(NULL, ET_Hook, 2, NULL, Param_Cell, Param_String);
	g_pPrecacheModel = forwards->CreateForwardEx(NULL, ET_Hook, 1, NULL, Param_String);
	g_pMapContentList = forwards->CreateForwardEx(NULL, ET_Hook, 1, NULL, Param_String);
	
	sharesys->AddNatives(myself, g_ExtensionNatives);
	sharesys->RegisterLibrary(myself, "phooks");
	return true;
}

void PHooks::SDK_OnUnload()
{
	for(int i = 0; i <= MAXPLAYERS; i++)
	{
		RemoveHook(i);
	}
	if(g_pGetItemInLoadout)
	{
		g_pGetItemInLoadout->Destroy();
		g_pGetItemInLoadout = NULL;
	}
	if(g_pItemSchema)
	{
		g_pItemSchema->Destroy();
		g_pItemSchema = NULL;
	}
	if(g_pGetItemDefintionByName)
	{
		g_pGetItemDefintionByName->Destroy();
		g_pGetItemDefintionByName = NULL;
	}
	if(g_pGetLoadoutSlot)
	{
		g_pGetLoadoutSlot->Destroy();
		g_pGetLoadoutSlot = NULL;
	}
	SH_REMOVE_HOOK(IServerGameDLL, LevelShutdown, gamedll, SH_STATIC(LevelShutdown), true);
	SH_REMOVE_HOOK(IVEngineServer, ClientPrintf, engine, SH_STATIC(ClientPrint), true);
}

void PHooks::SDK_OnAllLoaded()
{
	SM_GET_LATE_IFACE(BINTOOLS, g_pBinTools);
}

void PHooks::OnClientPutInServer(int client)
{
	CBaseEntity *pEnt = gamehelpers->ReferenceToEntity(client);
	if(pEnt)
	{
		g_iHookId[PHook_GiveNamedItem][client] = SH_ADD_MANUALHOOK(GiveNamedItemHook, pEnt, SH_STATIC(GiveNamedItem), true);
		g_iHookId[PHook_GiveNamedItemPre][client] = SH_ADD_MANUALHOOK(GiveNamedItemPreHook, pEnt, SH_STATIC(GiveNamedItemPre), false);
		g_iHookId[PHook_WeaponCanUse][client] = SH_ADD_MANUALHOOK(WeaponCanUseHook, pEnt, SH_STATIC(WeaponCanUse), true);
		g_iHookId[PHook_SetPlayerModel][client] = SH_ADD_MANUALHOOK(SetModelHook, pEnt, SH_STATIC(SetModel), true);
		g_iHookId[PHook_SetPlayerModelPre][client] = SH_ADD_MANUALHOOK(SetModelPreHook, pEnt, SH_STATIC(SetModelPre), false);
	}
}
void PHooks::OnClientDisconnected(int client)
{
	RemoveHook(client);
}

void LevelShutdown()
{
	for(int i = 0; i <= MAXPLAYERS; i++)
	{
		RemoveHook(i);
	}
}

void *GetItemSchema()
{
	static void *addr = NULL;
	if(!addr)
	{
		if(!g_pGameConf->GetMemSig("GetItemSchema", &addr) || !addr)
		{
			smutils->LogError(myself, "Failed to GetItemSchema location");
			return NULL;
		}
		PassInfo ret;
		ret.flags = PASSFLAG_BYVAL;
		ret.type = PassType_Basic;
		ret.size = sizeof(void *);
		g_pItemSchema = g_pBinTools->CreateCall(addr, CallConv_Cdecl, &ret, NULL, 0);
	}

	void *pSchema = NULL;
	g_pItemSchema->Execute(NULL, &pSchema);
	return pSchema;
}

int GetLoadoutSlot(void *pItemDef, int iTeam)
{
	static void *addr = NULL;
	if(!addr)
	{
		if(!g_pGameConf->GetMemSig("GetLoadoutSlot", &addr) || !addr)
		{
			smutils->LogError(myself, "Failed to GetLoadoutSlot location");
			return 0;
		}

		PassInfo pass[1];
		pass[0].flags = PASSFLAG_BYVAL;
		pass[0].type  = PassType_Basic;
		pass[0].size  = sizeof(int);

		PassInfo ret;
		ret.flags = PASSFLAG_BYVAL;
		ret.type = PassType_Basic;
		ret.size = sizeof(int);
		g_pGetLoadoutSlot = g_pBinTools->CreateCall(addr, CallConv_ThisCall, &ret, pass, 1);
	}

	unsigned char vstk[sizeof(void *) + sizeof(int)];
	unsigned char *vptr = vstk;

	*(void **)vptr = pItemDef;
	vptr += sizeof(void *);
	*(int *)vptr = iTeam;

	int slot = 0;
	g_pGetLoadoutSlot->Execute(vstk, &slot);

	return slot;
}

void *GetItemDefinitionByName(const char *szItem)
{
#ifdef WIN32
	void *temp = GetItemSchema();
	void *pSchema = (void *)((intptr_t)temp + 4);
#else
	void *pSchema = GetItemSchema();
#endif

	if(!pSchema)
		return 0;

	if(!g_pGetItemDefintionByName)
	{
		int offset = -1;

		if(!g_pGameConf->GetOffset("GetItemDefintionByName", &offset))
		{
			smutils->LogError(myself, "Failed to GetItemDefintionByName offset");
			return 0;
		}

		PassInfo pass[1];
		PassInfo ret;
		pass[0].flags = PASSFLAG_BYVAL;
		pass[0].type  = PassType_Basic;
		pass[0].size  = sizeof(const char *);

		ret.flags = PASSFLAG_BYREF;
		ret.type = PassType_Basic;
		ret.size = sizeof(void *);

		g_pGetItemDefintionByName = g_pBinTools->CreateVCall(offset, 0, 0, &ret, pass, 1);
	}

	unsigned char vstk[sizeof(void *) + sizeof(const char *)];
	unsigned char *vptr = vstk;

	*(void **)vptr = pSchema;
	vptr += sizeof(void *);
	*(const char **)vptr = szItem;

	void *pItemDef = 0;
	g_pGetItemDefintionByName->Execute(vstk, &pItemDef);
	return pItemDef;
}

static cell_t PHook(IPluginContext *pContext, const cell_t *params)
{
	switch(params[1])
	{
		case PHook_GiveNamedItem: return g_pGiveNamedItem->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_GiveNamedItemPre: return g_pGiveNamedItemPre->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_WeaponCanUse: return g_pWeaponCanUse->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_SetPlayerModel: return g_pSetModel->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_SetPlayerModelPre: return g_pSetModelPre->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_ConsolePrint: return g_pClientPrintf->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_PrecacheModel: return g_pPrecacheModel->AddFunction(pContext, static_cast<funcid_t>(params[2]));
		case PHook_MapContentList : return g_pMapContentList->AddFunction(pContext, static_cast<funcid_t>(params[2]));
	}
	return false;
}

static cell_t PUnHook(IPluginContext *pContext, const cell_t *params)
{
	switch(params[1])
	{
		case PHook_GiveNamedItem: return g_pGiveNamedItem->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_GiveNamedItemPre: return g_pGiveNamedItemPre->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_WeaponCanUse: return g_pWeaponCanUse->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_SetPlayerModel: return g_pSetModel->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_SetPlayerModelPre: return g_pSetModelPre->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_ConsolePrint: return g_pClientPrintf->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_PrecacheModel: return g_pPrecacheModel->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
		case PHook_MapContentList : return g_pMapContentList->RemoveFunction(pContext->GetFunctionById(static_cast<funcid_t>(params[2])));
	}
	return false;
}

static cell_t PHook_GetCEconItemView(IPluginContext *pContext, const cell_t *params)
{
	if ((params[1] < 1) || (params[1] > playerhelpers->GetMaxClients()))
	{
		return pContext->ThrowNativeError("Client index %d is invalid", params[1]);
	}
	CBaseEntity *pEntity;
	if((pEntity = gamehelpers->ReferenceToEntity(params[1])) == NULL)
	{
		return pContext->ThrowNativeError("Client %d is not in game", params[1]);
	}
	char *strSource; pContext->LocalToString(params[2], &strSource);
	void *pItemDef = GetItemDefinitionByName(strSource);
	if(pItemDef) return ((int)GetEconItemView(pItemDef, pEntity, ((int)params[3])));
	return 0;
}

static cell_t PHook_IsCustomItemView(IPluginContext *pContext, const cell_t *params)
{
	return (params[1] && ((CEconItemView *)params[1])->m_iItemDefinitionIndex != 0)?true:false;
}

static cell_t PHook_GivePlayerItem(IPluginContext *pContext, const cell_t *params)
{
	if ((params[1] < 1) || (params[1] > playerhelpers->GetMaxClients()))
	{
		return pContext->ThrowNativeError("Client index %d is invalid", params[1]);
	}
	CBaseEntity *pEntity;
	if((pEntity = gamehelpers->ReferenceToEntity(params[1])) == NULL)
	{
		return pContext->ThrowNativeError("Client %d is not in game", params[1]);
	}
	char *strSource; pContext->LocalToString(params[2], &strSource);
	cell_t pViewB = params[3];
	// Need to manually fire the forward.
	if(g_pGiveNamedItemPre->GetFunctionCount() > 0)
	{
		char szItemByf[64];
		strcpy(szItemByf, strSource);
		cell_t pViewNew = pViewB;
		cell_t res = PLUGIN_CONTINUE;
		g_pGiveNamedItemPre->PushCell(params[1]);
		g_pGiveNamedItemPre->PushStringEx(szItemByf, sizeof(szItemByf), SM_PARAM_STRING_COPY, SM_PARAM_COPYBACK);
		g_pGiveNamedItemPre->PushCellByRef(&pViewNew);
		g_pGiveNamedItemPre->Execute(&res);

		switch(res) 
		{
			case Pl_Changed:
			{
				strcpy(strSource, szItemByf);
				pViewB = pViewNew;
			}
			case Pl_Handled:
			case Pl_Stop:
			{
				return 0;
			}
		}
	}
	
	int entIndex = gamehelpers->EntityToBCompatRef(SH_MCALL(pEntity, GiveNamedItemPreHook)(strSource, 0, ((CEconItemView *)pViewB), false));
	// Need to manually fire the forward.
	if(g_pGiveNamedItem->GetFunctionCount() > 0)
	{
		g_pGiveNamedItem->PushCell(params[1]);
		g_pGiveNamedItem->PushString(strSource);
		g_pGiveNamedItem->PushCell(pViewB);
		g_pGiveNamedItem->PushCell(entIndex);
		g_pGiveNamedItem->Execute();
	}
	return entIndex;
}

CBaseEntity *GiveNamedItem(const char *szItem, int iSubType, CEconItemView *pView, bool removeIfNotCarried)
{
	if(g_pGiveNamedItem->GetFunctionCount() > 0)
	{
		g_pGiveNamedItem->PushCell(gamehelpers->EntityToBCompatRef(META_IFACEPTR(CBaseEntity)));
		g_pGiveNamedItem->PushString(szItem);
		g_pGiveNamedItem->PushCell(((cell_t)pView));
		g_pGiveNamedItem->PushCell(gamehelpers->EntityToBCompatRef(META_RESULT_ORIG_RET(CBaseEntity *)));
		g_pGiveNamedItem->Execute();
	}
	RETURN_META_VALUE(MRES_IGNORED, NULL);
}

CBaseEntity *GiveNamedItemPre(const char *szItem, int iSubType, CEconItemView *pView, bool removeIfNotCarried)
{
	if(g_pGiveNamedItemPre->GetFunctionCount() > 0)
	{
		char szItemByf[64];
		strcpy(szItemByf, szItem);
		cell_t pViewNew = ((cell_t)pView);
		cell_t res = PLUGIN_CONTINUE;
		g_pGiveNamedItemPre->PushCell(gamehelpers->EntityToBCompatRef(META_IFACEPTR(CBaseEntity)));
		g_pGiveNamedItemPre->PushStringEx(szItemByf, sizeof(szItemByf), SM_PARAM_STRING_COPY, SM_PARAM_COPYBACK);
		g_pGiveNamedItemPre->PushCellByRef(&pViewNew);
		g_pGiveNamedItemPre->Execute(&res);

		switch(res) 
		{
			case Pl_Changed:
			{
				RETURN_META_VALUE_MNEWPARAMS(MRES_HANDLED, NULL, GiveNamedItemPreHook, (((const char *)szItemByf), iSubType, ((CEconItemView *)pViewNew), removeIfNotCarried));
			}
			case Pl_Handled:
			case Pl_Stop:
			{
				RETURN_META_VALUE(MRES_SUPERCEDE, NULL);
			}
		}
	}
	RETURN_META_VALUE(MRES_IGNORED, NULL);
}

bool WeaponCanUse(CBaseCombatWeapon *pWeapon)
{
	if(g_pWeaponCanUse->GetFunctionCount() > 0)
	{
		cell_t res = META_RESULT_ORIG_RET(bool);
		cell_t ret = res;
		g_pWeaponCanUse->PushCell(gamehelpers->EntityToBCompatRef(META_IFACEPTR(CBaseEntity)));
		g_pWeaponCanUse->PushCell(gamehelpers->EntityToBCompatRef(pWeapon));
		g_pWeaponCanUse->PushCell(ret);
		g_pWeaponCanUse->Execute(&res);
		if(ret != res)
		{
			RETURN_META_VALUE(MRES_SUPERCEDE, res);
		}
	}
	RETURN_META_VALUE(MRES_IGNORED, true);
}

CBaseEntity *SetModel(const char *sModel)
{
	if(g_pSetModel->GetFunctionCount() > 0)
	{
		g_pSetModel->PushCell(gamehelpers->EntityToBCompatRef(META_IFACEPTR(CBaseEntity)));
		g_pSetModel->PushString(sModel);
		g_pSetModel->Execute();
	}
	RETURN_META_VALUE(MRES_IGNORED, NULL);
}

CBaseEntity *SetModelPre(const char *sModel)
{
	if(g_pSetModelPre->GetFunctionCount() > 0)
	{
		CBaseEntity *pEnt = META_IFACEPTR(CBaseEntity);
		char sModelNew[128];
		strcpy(sModelNew, sModel);
		cell_t res = PLUGIN_CONTINUE;
		g_pSetModelPre->PushCell(gamehelpers->EntityToBCompatRef(pEnt));
		g_pSetModelPre->PushString(playerhelpers->GetGamePlayer(gamehelpers->EntityToBCompatRef(pEnt))->GetPlayerInfo()->GetModelName());
		g_pSetModelPre->PushStringEx(sModelNew, sizeof(sModelNew), SM_PARAM_STRING_COPY, SM_PARAM_COPYBACK);
		g_pSetModelPre->Execute(&res);

		switch(res) 
		{
			case Pl_Changed:
			{
				RETURN_META_VALUE_MNEWPARAMS(MRES_HANDLED, NULL, SetModelPreHook, (((const char *)sModelNew)));
			}
			case Pl_Handled:
			case Pl_Stop:
			{
				RETURN_META_VALUE(MRES_SUPERCEDE, NULL);
			}
		}
	}
	RETURN_META_VALUE(MRES_IGNORED, NULL);
}

void ClientPrint(edict_t *pEdict, const char *szMsg)
{
	if(g_pClientPrintf->GetFunctionCount() > 0)
	{
		char cMsg[192];
		strcpy(cMsg, szMsg);
		cell_t res = PLUGIN_CONTINUE;
		g_pClientPrintf->PushCell(gamehelpers->IndexOfEdict(pEdict));
		g_pClientPrintf->PushStringEx(cMsg, sizeof(cMsg), SM_PARAM_STRING_UTF8|SM_PARAM_STRING_COPY, SM_PARAM_COPYBACK);
		g_pClientPrintf->Execute(&res);
		
		switch(res) 
		{
			case Pl_Changed:
			{
				RETURN_META_NEWPARAMS(MRES_IGNORED, &IVEngineServer::ClientPrintf, (pEdict, ((const char *)cMsg)));
			}
			case Pl_Handled:
			case Pl_Stop:
			{
				RETURN_META(MRES_SUPERCEDE);
			}
		}
	}
	RETURN_META(MRES_IGNORED);
}

int PrecacheModel(const char *sModel, bool preload)
{
	if(g_pPrecacheModel->GetFunctionCount() > 0)
	{
		cell_t res = PLUGIN_CONTINUE;
		g_pPrecacheModel->PushString(sModel);
		g_pPrecacheModel->Execute(&res);

		switch(res) 
		{
			case Pl_Handled:
			case Pl_Stop:
			{
				RETURN_META_VALUE(MRES_SUPERCEDE, 0);
			}
		}
	}
	RETURN_META_VALUE(MRES_IGNORED, 0);
}

CEconItemView *GetEconItemView(void *pItemDef, CBaseEntity *pEnt, int iTeam)
{
	if(!g_pGetItemInLoadout)
	{
		PassInfo pass[2];
		PassInfo ret;
		pass[0].flags = PASSFLAG_BYVAL;
		pass[0].type  = PassType_Basic;
		pass[0].size  = sizeof(int);
		pass[1].flags = PASSFLAG_BYVAL;
		pass[1].type  = PassType_Basic;
		pass[1].size  = sizeof(int);

		ret.flags = PASSFLAG_BYVAL;
		ret.type = PassType_Basic;
		ret.size = sizeof(void *);

		g_pGetItemInLoadout = g_pBinTools->CreateVCall(g_iGetItemInLoadout, 0, 0, &ret, pass, 2);
	}
	
	int iLoadoutSlot = GetLoadoutSlot(pItemDef, iTeam);
	if(iLoadoutSlot == -1)
	{
		return NULL;
	}
	
	unsigned char vstk[sizeof(void *) + sizeof(int) * 2];
	unsigned char *vptr = vstk;

	*(void **)vptr = (void *)((intptr_t)pEnt + g_iInventoryOffset);
	vptr += sizeof(void *);
	*(int *)vptr = iTeam;
	vptr += sizeof(int);
	*(int *)vptr = iLoadoutSlot;
	
	CEconItemView *pView = NULL;
	g_pGetItemInLoadout->Execute(vstk, &pView);

	return pView;
}

void RemoveHook(int client)
{
	if(g_iHookId[PHook_GiveNamedItem][client] != 0)
	{
		SH_REMOVE_HOOK_ID(g_iHookId[PHook_GiveNamedItem][client]);
		g_iHookId[PHook_GiveNamedItem][client] = 0;
	}
	if(g_iHookId[PHook_GiveNamedItemPre][client] != 0)
	{
		SH_REMOVE_HOOK_ID(g_iHookId[PHook_GiveNamedItemPre][client]);
		g_iHookId[PHook_GiveNamedItemPre][client] = 0;
	}
	if(g_iHookId[PHook_WeaponCanUse][client] != 0)
	{
		SH_REMOVE_HOOK_ID(g_iHookId[PHook_WeaponCanUse][client]);
		g_iHookId[PHook_WeaponCanUse][client] = 0;
	}
	if(g_iHookId[PHook_SetPlayerModel][client] != 0)
	{
		SH_REMOVE_HOOK_ID(g_iHookId[PHook_SetPlayerModel][client]);
		g_iHookId[PHook_SetPlayerModel][client] = 0;
	}
	if(g_iHookId[PHook_SetPlayerModelPre][client] != 0)
	{
		SH_REMOVE_HOOK_ID(g_iHookId[PHook_SetPlayerModelPre][client]);
		g_iHookId[PHook_SetPlayerModelPre][client] = 0;
	}
}